"""
RxTracker Backend - FastAPI
Prescription reader + medicine tracker/reminder API
"""

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import base64
import json
import os
import httpx
from datetime import datetime, date
from database import get_db, init_db
import sqlite3

app = FastAPI(title="RxTracker API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def startup():
    init_db()

# ─── Models ────────────────────────────────────────────────────────────────────

class Medicine(BaseModel):
    name: str
    dosage: str
    frequency: str          # "once_daily", "twice_daily", "three_times_daily", "every_x_hours"
    times: list[str]        # ["08:00", "20:00"]
    start_date: str         # ISO date
    end_date: Optional[str] = None
    instructions: Optional[str] = None
    stock: Optional[int] = None  # pill count

class MedicineUpdate(BaseModel):
    name: Optional[str] = None
    dosage: Optional[str] = None
    frequency: Optional[str] = None
    times: Optional[list[str]] = None
    end_date: Optional[str] = None
    instructions: Optional[str] = None
    stock: Optional[int] = None

class DoseLog(BaseModel):
    medicine_id: int
    scheduled_time: str     # ISO datetime
    taken: bool
    taken_at: Optional[str] = None  # ISO datetime

# ─── Prescription OCR ──────────────────────────────────────────────────────────

@app.post("/api/prescriptions/scan")
async def scan_prescription(file: UploadFile = File(...)):
    """
    Upload a prescription image and extract medicine info using Claude Vision.
    Falls back to mock data if ANTHROPIC_API_KEY is not set.
    """
    image_data = await file.read()
    b64_image = base64.standard_b64encode(image_data).decode("utf-8")

    content_type = file.content_type or "image/jpeg"
    api_key = os.getenv("ANTHROPIC_API_KEY")

    if not api_key:
        # Return mock data for testing without API key
        return {
            "raw_text": "Mock prescription: Amoxicillin 500mg, take 3x daily for 7 days",
            "medicines": [
                {
                    "name": "Amoxicillin",
                    "dosage": "500mg",
                    "frequency": "three_times_daily",
                    "times": ["08:00", "14:00", "20:00"],
                    "instructions": "Take with food. Complete full course.",
                    "duration_days": 7
                }
            ],
            "note": "Mock response - set ANTHROPIC_API_KEY for real OCR"
        }

    prompt = """Analyze this prescription image. Extract ALL medicines and return ONLY valid JSON (no markdown, no explanation):

{
  "raw_text": "full text from prescription",
  "medicines": [
    {
      "name": "medicine name",
      "dosage": "e.g. 500mg",
      "frequency": "once_daily|twice_daily|three_times_daily|four_times_daily",
      "times": ["HH:MM", ...],
      "instructions": "any special instructions",
      "duration_days": null or number
    }
  ]
}

Infer times from frequency:
- once_daily: ["08:00"]
- twice_daily: ["08:00", "20:00"]
- three_times_daily: ["08:00", "14:00", "20:00"]
- four_times_daily: ["08:00", "12:00", "16:00", "20:00"]

If you cannot read the prescription clearly, still return the JSON structure with best guesses."""

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 1024,
                "messages": [{
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": content_type,
                                "data": b64_image
                            }
                        },
                        {"type": "text", "text": prompt}
                    ]
                }]
            }
        )

    if resp.status_code != 200:
        raise HTTPException(500, f"Vision API error: {resp.text}")

    result = resp.json()
    text = result["content"][0]["text"].strip()

    # Strip markdown fences if present
    if text.startswith("```"):
        text = text.split("```")[1]
        if text.startswith("json"):
            text = text[4:]

    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        parsed = {"raw_text": text, "medicines": [], "parse_error": True}

    return parsed

# ─── Medicines CRUD ────────────────────────────────────────────────────────────

@app.get("/api/medicines")
def list_medicines():
    db = get_db()
    rows = db.execute(
        "SELECT * FROM medicines ORDER BY created_at DESC"
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.post("/api/medicines", status_code=201)
def create_medicine(med: Medicine):
    db = get_db()
    cur = db.execute(
        """INSERT INTO medicines (name, dosage, frequency, times, start_date, end_date, instructions, stock)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            med.name, med.dosage, med.frequency,
            json.dumps(med.times),
            med.start_date, med.end_date,
            med.instructions, med.stock
        )
    )
    db.commit()
    row = db.execute("SELECT * FROM medicines WHERE id=?", (cur.lastrowid,)).fetchone()
    db.close()
    return dict(row)

@app.get("/api/medicines/{medicine_id}")
def get_medicine(medicine_id: int):
    db = get_db()
    row = db.execute("SELECT * FROM medicines WHERE id=?", (medicine_id,)).fetchone()
    db.close()
    if not row:
        raise HTTPException(404, "Medicine not found")
    return dict(row)

@app.patch("/api/medicines/{medicine_id}")
def update_medicine(medicine_id: int, update: MedicineUpdate):
    db = get_db()
    row = db.execute("SELECT * FROM medicines WHERE id=?", (medicine_id,)).fetchone()
    if not row:
        db.close()
        raise HTTPException(404, "Medicine not found")

    fields = {k: v for k, v in update.dict().items() if v is not None}
    if "times" in fields:
        fields["times"] = json.dumps(fields["times"])

    set_clause = ", ".join(f"{k}=?" for k in fields)
    values = list(fields.values()) + [medicine_id]
    db.execute(f"UPDATE medicines SET {set_clause} WHERE id=?", values)
    db.commit()
    row = db.execute("SELECT * FROM medicines WHERE id=?", (medicine_id,)).fetchone()
    db.close()
    return dict(row)

@app.delete("/api/medicines/{medicine_id}", status_code=204)
def delete_medicine(medicine_id: int):
    db = get_db()
    db.execute("DELETE FROM medicines WHERE id=?", (medicine_id,))
    db.execute("DELETE FROM dose_logs WHERE medicine_id=?", (medicine_id,))
    db.commit()
    db.close()

# ─── Dose Logging ──────────────────────────────────────────────────────────────

@app.get("/api/doses/today")
def get_today_doses():
    """Get all scheduled doses for today with their log status."""
    today = date.today().isoformat()
    db = get_db()

    medicines = db.execute(
        "SELECT * FROM medicines WHERE start_date <= ? AND (end_date IS NULL OR end_date >= ?)",
        (today, today)
    ).fetchall()

    result = []
    for med in medicines:
        times = json.loads(med["times"])
        for t in times:
            scheduled_dt = f"{today}T{t}:00"
            log = db.execute(
                "SELECT * FROM dose_logs WHERE medicine_id=? AND scheduled_time=?",
                (med["id"], scheduled_dt)
            ).fetchone()

            result.append({
                "medicine_id": med["id"],
                "medicine_name": med["name"],
                "dosage": med["dosage"],
                "instructions": med["instructions"],
                "scheduled_time": scheduled_dt,
                "time_label": t,
                "taken": log["taken"] if log else False,
                "taken_at": log["taken_at"] if log else None,
                "log_id": log["id"] if log else None,
            })

    db.close()
    result.sort(key=lambda x: x["scheduled_time"])
    return result

@app.post("/api/doses/log")
def log_dose(dose: DoseLog):
    """Mark a dose as taken or not taken."""
    db = get_db()

    existing = db.execute(
        "SELECT * FROM dose_logs WHERE medicine_id=? AND scheduled_time=?",
        (dose.medicine_id, dose.scheduled_time)
    ).fetchone()

    now = datetime.now().isoformat()

    if existing:
        db.execute(
            "UPDATE dose_logs SET taken=?, taken_at=? WHERE id=?",
            (dose.taken, now if dose.taken else None, existing["id"])
        )
        log_id = existing["id"]
    else:
        cur = db.execute(
            "INSERT INTO dose_logs (medicine_id, scheduled_time, taken, taken_at) VALUES (?, ?, ?, ?)",
            (dose.medicine_id, dose.scheduled_time, dose.taken, now if dose.taken else None)
        )
        log_id = cur.lastrowid

    # Decrement stock if taken
    if dose.taken:
        db.execute(
            "UPDATE medicines SET stock = stock - 1 WHERE id=? AND stock > 0",
            (dose.medicine_id,)
        )

    db.commit()
    log = db.execute("SELECT * FROM dose_logs WHERE id=?", (log_id,)).fetchone()
    db.close()
    return dict(log)

@app.get("/api/doses/history")
def get_dose_history(medicine_id: Optional[int] = None, days: int = 7):
    db = get_db()
    if medicine_id:
        rows = db.execute(
            """SELECT dl.*, m.name as medicine_name, m.dosage
               FROM dose_logs dl JOIN medicines m ON dl.medicine_id = m.id
               WHERE dl.medicine_id=?
               ORDER BY dl.scheduled_time DESC LIMIT ?""",
            (medicine_id, days * 10)
        ).fetchall()
    else:
        rows = db.execute(
            """SELECT dl.*, m.name as medicine_name, m.dosage
               FROM dose_logs dl JOIN medicines m ON dl.medicine_id = m.id
               ORDER BY dl.scheduled_time DESC LIMIT ?""",
            (days * 20,)
        ).fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.get("/api/doses/stats")
def get_stats():
    """Adherence stats per medicine."""
    db = get_db()
    medicines = db.execute("SELECT * FROM medicines").fetchall()
    result = []
    for med in medicines:
        logs = db.execute(
            "SELECT * FROM dose_logs WHERE medicine_id=?", (med["id"],)
        ).fetchall()
        total = len(logs)
        taken = sum(1 for l in logs if l["taken"])
        result.append({
            "medicine_id": med["id"],
            "medicine_name": med["name"],
            "total_doses_logged": total,
            "doses_taken": taken,
            "adherence_pct": round((taken / total * 100) if total > 0 else 0, 1),
            "stock": med["stock"],
        })
    db.close()
    return result

@app.get("/health")
def health():
    return {"status": "ok", "time": datetime.now().isoformat()}
